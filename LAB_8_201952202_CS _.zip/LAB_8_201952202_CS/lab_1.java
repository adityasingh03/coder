//201952202
import java.io.*;
import java.util.*; 
class lab_1
{ 
public double average(String ar[]) throws NullPointerException,NumberFormatException
{
String s;
int l=ar.length;
int l1=l;
double doub=0,sum=0,avg;
for(int i=0;i<l;i++)
{
 try
{
s=ar[i];
doub=Double.parseDouble(s);
}

catch(NullPointerException e) 
{   
doub=0;
l1--;
System.out.println("NullPointerException Caught"); 
}

catch(NumberFormatException e) 
{   
doub=0;
l1--;
System.out.println("NumberFormatException Caught");         
}

sum=sum+doub;
}

avg=sum/l1;
System.out.println("Average is:");
return avg;
}

//Main

    public static void main (String[] args) 
    { 

       
String a[] = {"4.32","2.20","b","","3","0",null,"8.00"}; //The Indexes having non-double values are not included in total to calculate average
lab_1 ob=new lab_1();
System.out.print(ob.average(a));

    } 
}