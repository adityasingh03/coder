//201952202
class RangeException extends Exception//201952202
{
RangeException(String s)
{
super(s);
}
}

public class lab_2 
{
public static double add(String[] ar)throws NumberFormatException, RangeException
{
double s =0.0;
for(int i=0;i<ar.length;i++){
double v = Double.parseDouble(ar[i]);
if(v<0 || v>1){
throw new RangeException("Number exceeds range as it should be between 0 and 1");
}
s=s+v;
}
return s;
}

public static void main(String[] args)
{
String[] array = new String[]{"0.7","0.3","0.2"};
try
{
double s = add(array);
System.out.println(s);
}
catch(RangeException e)
{
System.out.println("Exception Occured:"+ e);
}
catch(NumberFormatException e)
{
System.out.println("Not A valid number");
}
finally
{
System.out.println("Thank you for using this program");
}
}

}