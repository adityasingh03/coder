 class a//Just for checking and no real function
{
 public void as()
{
System.out.println("A");
}
}

 class b extends a//Just for checking and no real function
{
 public void asb()
{
System.out.println("A");
}
}
 class c extends b//Just for checking and no real function
{
 public void asbc()
{
System.out.println("A");
}
}

//Main 
public class lab_3 extends c
{
public static void main(String[] args) 
{
int a=0;
lab_3 o=new lab_3();
System.out.println("Name of superclasses are");
try
{
Class C = o.getClass();
while (C != null) {
C = C.getSuperclass();
System.out.println(C.getName());
a++;
}
}
catch(NullPointerException e)
{
}
System.out.println("Number of superclasses");
System.out.println(a);
}
 
}