package com.company;
import java.io.*;

public class lab_41 {

    public static void main(String[] args) {


        System.out.println("Enter N for the Fibonacci series");
        int n = Integer.parseInt(args[0]);


        System.out.println("Enter the name of file in C drive");
        String str = args[1];

        int[] series = new int[n+1];

        int t1=0,t2=1;

        for (int i = 1; i <= n; ++i)
        {
            series[i] = t1;

            int sum = t1 + t2;
            t1 = t2;
            t2 = sum;
        }


        try{
            FileWriter Writer = new FileWriter("C:\\"+str);
            for(int i=0;i<n+1;i++){
                Writer.write(Integer.toString(series[i]));
                Writer.write("  ");
            }

            Writer.close();
            System.out.println("File has been succefully written in C drive");
        } catch (IOException e) {
            System.out.println("An error has occured");
            System.out.println(e);
        }
    }
}