package com.company;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class lab_42
 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the name of the file in D drive");
        String name = args[0];

        try{
            File myFile = new File("D:\\"+name);
            Scanner myReader = new Scanner(myFile);
            while(myReader.hasNextLine()){
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        }
        catch(FileNotFoundException e) {
            System.out.println("An error has occured");
            System.out.println(e);
        }
    }
}