import java.io.*; //201952202 AdityaSingh
import java.util.*;  
public class lab_5
{ 
static void RecursivePrint(File[] a,int in,int le)throws NullPointerException 
{ 
try
{
if(in == a.length) 
return; 
for (int i=0; i<le; i++) 
System.out.print("   "); 
if(a[in].isFile()) 
System.out.println(a[in].getName()); 
else 
if(a[in].isDirectory()) 
{ 
System.out.println("[" + a[in].getName() + "]"); 
RecursivePrint(a[in].listFiles(), 0, le + 1); 
} 
RecursivePrint(a,++in, le); 
}
catch(NullPointerException e)
{
System.out.println("NullPointerException");
} 
}
//Main Method
public static void main(String[] args) 
{ 

String maindirpath = args[0];//command Line argument
File maindir = new File(maindirpath); 
if(maindir.exists() && maindir.isDirectory()) 
{ 
File arr[] = maindir.listFiles(); 
if(arr[0].isFile()) 
{
System.out.println("It is a File with Name ");
System.out.println(arr[0].getName()); 
}
else
{
System.out.println("It is a Directory and Its content are");
System.out.println("Files from main directory : " + maindir); 
System.out.println();
RecursivePrint(arr,0,0);  
}
}  
} 
}